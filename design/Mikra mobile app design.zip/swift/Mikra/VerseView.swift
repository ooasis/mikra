import SwiftUI

enum VerseMode { case passive, wave }

/// What sits under each word of a verse: nothing, its meaning, or how to say it.
enum VerseHelp: String, CaseIterable, Identifiable {
    case none, meaning, reading
    var id: String { rawValue }
    var label: String {
        switch self {
        case .none: return ui("None", "无")
        case .meaning: return ui("Meaning", "含义")
        case .reading: return ui("Reading", "读音")
        }
    }
}

/// One verse per page; swipe to move through the chapter.
struct VerseView: View {
    let verse: Verse
    let mode: VerseMode
    @State private var index: Int

    init(verse: Verse, mode: VerseMode) {
        self.verse = verse
        self.mode = mode
        _index = State(initialValue: Self.chapter(of: verse).firstIndex { $0.id == verse.id } ?? 0)
    }

    /// The pages: the verse's chapter. A page TabView builds every page up front, and Psalms has 2,527 verses.
    private var verses: [Verse] { Self.chapter(of: verse) }
    private static func chapter(of verse: Verse) -> [Verse] {
        book(named: verse.book).verses.filter { $0.c == verse.c }
    }

    var body: some View {
        TabView(selection: $index) {
            ForEach(Array(verses.enumerated()), id: \.element.id) { i, v in
                VersePage(verse: v, mode: mode, chapter: verses, position: i,
                          jump: { j in withAnimation { index = j } })
                    .environment(\.layoutDirection, .leftToRight) // content stays LTR
                    .tag(i)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .environment(\.layoutDirection, .rightToLeft) // pages advance right-to-left, like Hebrew
        .background(Theme.ground)
        .onChange(of: index) { Speech.stop(); Recorder.shared.stop() }
        .onDisappear { Recorder.shared.stop() }
    }
}

/// The reader keeps its controls out of the way: tap a word to hear it, hold the verse to hear it
/// all, swipe up for help, pace and recording. A hint line at the bottom says so, always.
private struct VersePage: View {
    let verse: Verse
    let mode: VerseMode
    let chapter: [Verse]
    let position: Int
    let jump: (Int) -> Void
    @EnvironmentObject var store: Store
    @ObservedObject private var monitor = SpeechMonitor.shared
    @ObservedObject private var recorder = Recorder.shared
    @Environment(\.dismiss) private var dismiss

    /// Passive reading shows text and translation at once; the wave hides the translation until Check.
    private enum Stage { case read, check }
    @State private var stage: Stage
    /// Which word's sheet is open. By index, since a verse can repeat a word.
    private struct WordPick: Identifiable { let index: Int; var id: Int { index } }
    @State private var picked: WordPick?
    @State private var showControls = false

    init(verse: Verse, mode: VerseMode, chapter: [Verse], position: Int, jump: @escaping (Int) -> Void) {
        self.verse = verse
        self.mode = mode
        self.chapter = chapter
        self.position = position
        self.jump = jump
        _stage = State(initialValue: mode == .passive ? .check : .read)
    }

    var body: some View {
        VStack(spacing: 0) {
            header
            rail
            ScrollView { readStage }
            if mode == .wave { footer } // the wave's Check / Owned it flow stays in view
            hint
        }
        .contentShape(.rect)
        .simultaneousGesture(LongPressGesture(minimumDuration: 0.45).onEnded { _ in
            Speech.say(verse: verse, pace: store.pace)
        })
        .simultaneousGesture(DragGesture(minimumDistance: 24).onEnded { g in
            let t = g.translation
            if t.height < -60, abs(t.height) > abs(t.width) { showControls = true }
        })
        .sheet(item: $picked) { pick in
            WordSheet(words: verse.words, index: pick.index)
                .presentationDetents([.height(340)])
                .presentationBackground(Theme.surface)
        }
        .sheet(isPresented: $showControls) {
            controls
                .presentationDetents([.height(mode == .passive ? 360 : 300)])
                .presentationDragIndicator(.visible)
                .presentationBackground(Theme.surface)
        }
    }

    private var header: some View {
        HStack(spacing: 10) {
            Button { dismiss() } label: {
                Image(systemName: "xmark").font(.subheadline.weight(.semibold))
                    .frame(width: 36, height: 36)
                    .overlay(RoundedRectangle(cornerRadius: Theme.radius).strokeBorder(Theme.divider))
                    .contentShape(.rect)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(ui("Close", "关闭"))
            CrumbLine(trail: [tr(verse.book), "\(verse.c):\(verse.v)"])
            Spacer()
        }
        .padding(.horizontal)
        .padding(.vertical, 6)
    }

    /// One tick per verse of the chapter, right to left; the current one stands tall, read ones tint.
    private var rail: some View {
        ScrollViewReader { proxy in
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 4) {
                    ForEach(Array(chapter.enumerated()), id: \.element.id) { i, v in
                        Button { jump(i) } label: {
                            VStack(spacing: 4) {
                                Capsule().fill(tick(i, v)).frame(width: 2, height: i == position ? 18 : 8)
                                Text("\(v.v)").font(.system(size: 10).monospacedDigit()).foregroundStyle(tick(i, v))
                            }
                            .frame(width: 20, height: 36, alignment: .bottom)
                        }
                        .buttonStyle(.plain)
                        .id(i)
                    }
                }
                .padding(.horizontal)
            }
            .environment(\.layoutDirection, .rightToLeft)
            .onAppear { proxy.scrollTo(position, anchor: .center) }
        }
        .padding(.bottom, 8)
    }

    private func tick(_ i: Int, _ v: Verse) -> Color {
        if i == position { return Theme.accent }
        return store.verses[v.id]?.passive != nil ? Theme.accent700 : Theme.neutral700
    }

    private var readStage: some View {
        VStack(alignment: .leading, spacing: 14) {
            if mode == .wave && stage == .read {
                Text(ui("Second wave — read it aloud, no help.", "第二遍：不看提示，大声读出来。"))
                    .font(.subheadline)
                    .foregroundStyle(Theme.neutral400)
            }
            VStack(alignment: .leading, spacing: 12) {
                Text("\(verse.book.uppercased()) · \(tr(verse.book)) \(verse.c):\(verse.v)")
                    .font(.caption2).tracking(1).foregroundStyle(Theme.accent)
                VerseFlow {
                    ForEach(Array(verse.words.enumerated()), id: \.offset) { i, word in
                        Button {
                            picked = WordPick(index: i)
                            Speech.say(word.h)
                        } label: {
                            VStack(spacing: 2) {
                                Text(pointed(word.h))
                                    .font(.system(size: 40))
                                    .foregroundStyle(Theme.text)
                                    .padding(.vertical, 2)
                                    .padding(.horizontal, 3)
                                    .background(monitor.spokenWord == i ? Theme.accent800 : .clear,
                                                in: RoundedRectangle(cornerRadius: 6))
                                    .animation(.easeOut(duration: 0.12), value: monitor.spokenWord == i)
                                    .overlay(alignment: .bottom) {
                                        if word.n != nil { // a micro-note waits in the word sheet
                                            Circle().fill(Theme.accent).frame(width: 4, height: 4).offset(y: 4)
                                        }
                                    }
                                if let help = help(for: word) {
                                    Text(help)
                                        .font(.caption2)
                                        .foregroundStyle(Theme.neutral400)
                                        .multilineTextAlignment(.center)
                                        .lineLimit(2)
                                        .frame(maxWidth: 90)
                                }
                            }
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 16)
            .cardSurface()

            if stage == .check {
                Text(verse.text)
                    .font(.title3)
                    .foregroundStyle(Theme.neutral400)
                    .padding(.horizontal, 2)
            }
        }
        .padding(.horizontal)
        .padding(.bottom)
    }

    private func help(for word: VerseWord) -> String? {
        switch store.verseHelp {
        case .none: return nil
        case .meaning: return tr(word.g)
        case .reading: return pronounce(word.h)
        }
    }

    /// Tapping the hint opens the controls too, for anyone who doesn't swipe.
    private var hint: some View {
        Button { showControls = true } label: {
            VStack(spacing: 3) {
                Image(systemName: "chevron.up").font(.caption2)
                Text(ui("Tap a word · hold to play · swipe up for controls · swipe for next",
                        "点词 听音 · 长按 朗读 · 上滑 控制 · 横滑 换节"))
                    .font(.caption2)
            }
            .foregroundStyle(Theme.neutral500)
            .frame(maxWidth: .infinity)
            .padding(.vertical, 6)
            .contentShape(.rect)
        }
        .buttonStyle(.plain)
    }

    // — The swipe-up sheet —

    private var controls: some View {
        VStack(alignment: .leading, spacing: 14) {
            group(ui("Under each word", "每个词下方")) {
                Picker("", selection: Binding(get: { store.verseHelp }, set: { store.setVerseHelp($0) })) {
                    ForEach(VerseHelp.allCases) { Text($0.label).tag($0) }
                }
                .pickerStyle(.segmented)
            }
            group(ui("Read the verse · tap again to replay", "朗读整节 · 再点一次重播")) { paceControls }
            group(ui("Read along", "跟读")) { recordControls }
            if mode == .passive {
                Button {
                    store.completePassive(verse)
                    showControls = false
                    // let the sheet go first, then close the reader under it
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { dismiss() }
                } label: {
                    Label(ui("Done", "读完了"), systemImage: "checkmark")
                }
                .buttonStyle(OutlineButtonStyle())
            }
        }
        .padding()
        .padding(.top, 8)
    }

    private func group<C: View>(_ title: String, @ViewBuilder _ content: () -> C) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title).font(.caption).foregroundStyle(Theme.neutral400)
            content()
        }
    }

    /// Each button plays the verse at its own pace — tapping the current one replays,
    /// which is why these are buttons rather than a Picker.
    private var paceControls: some View {
        HStack(spacing: 8) {
            ForEach(Pace.allCases) { pace in
                let isCurrent = store.pace == pace
                Button {
                    store.setPace(pace)
                    Speech.say(verse: verse, pace: pace)
                } label: {
                    Label(pace.label, systemImage: "play")
                        .font(.subheadline)
                        .foregroundStyle(isCurrent ? Theme.accent : Theme.text)
                        .frame(maxWidth: .infinity, minHeight: 42)
                        .overlay(RoundedRectangle(cornerRadius: Theme.radius)
                            .strokeBorder(isCurrent ? Theme.accent : Theme.divider))
                        .contentShape(.rect)
                }
                .buttonStyle(.plain)
            }
        }
    }

    /// Record yourself, then hear it back next to the synthesized reading.
    private var recordControls: some View {
        let hasTake = Recorder.hasTake(for: verse)
        return HStack(spacing: 8) {
            Button {
                recorder.isRecording ? recorder.stop() : recorder.record(verse)
            } label: {
                Label(recorder.isRecording ? ui("Stop", "停止") : ui("Record me", "录我"),
                      systemImage: recorder.isRecording ? "stop.fill" : "mic")
                    .foregroundStyle(recorder.isRecording ? Theme.text : Theme.accent300)
                    .frame(maxWidth: .infinity, minHeight: 42)
                    .background(recorder.isRecording ? Theme.accent800 : .clear,
                                in: RoundedRectangle(cornerRadius: Theme.radius))
                    .overlay(RoundedRectangle(cornerRadius: Theme.radius)
                        .strokeBorder(recorder.isRecording ? Theme.accent : Theme.divider))
            }
            Button {
                recorder.isPlaying ? recorder.stop() : recorder.play(verse)
            } label: {
                Label(recorder.isPlaying ? ui("Stop", "停止") : ui("Play me", "播放我"),
                      systemImage: recorder.isPlaying ? "stop.fill" : "play")
                    .frame(maxWidth: .infinity, minHeight: 42)
                    .overlay(RoundedRectangle(cornerRadius: Theme.radius).strokeBorder(Theme.divider))
            }
            .disabled(recorder.isRecording || !hasTake)
            .opacity(recorder.isRecording || !hasTake ? 0.45 : 1)
            ShareLink(item: Recorder.url(for: verse)) {
                Label(ui("Share", "分享"), systemImage: "square.and.arrow.up")
                    .frame(maxWidth: .infinity, minHeight: 42)
                    .overlay(RoundedRectangle(cornerRadius: Theme.radius).strokeBorder(Theme.divider))
            }
            .disabled(recorder.isRecording || !hasTake)
            .opacity(recorder.isRecording || !hasTake ? 0.45 : 1)
        }
        .buttonStyle(.plain)
        .font(.subheadline)
    }

    // — The second wave keeps its own footer —

    private var footer: some View {
        Group {
            switch stage {
            case .read:
                Button(ui("Check", "核对")) {
                    stage = .check
                    Speech.say(verse: verse, pace: store.pace)
                }
                .buttonStyle(OutlineButtonStyle())
            case .check:
                HStack(spacing: 8) {
                    Button(ui("Struggled", "还不熟")) { dismiss() } // stays in the wave queue
                        .buttonStyle(OutlineButtonStyle(prominent: false))
                    Button {
                        store.completeWave(verse)
                        dismiss()
                    } label: {
                        Label(ui("Owned it", "掌握了"), systemImage: "checkmark")
                    }
                    .buttonStyle(OutlineButtonStyle())
                }
            }
        }
        .padding(.horizontal)
        .padding(.top, 6)
    }
}

/// One word at a time; swipe to walk through the verse.
private struct WordSheet: View {
    let words: [VerseWord]
    @State var index: Int

    var body: some View {
        TabView(selection: $index) {
            ForEach(Array(words.enumerated()), id: \.offset) { i, word in
                page(word, position: i)
                    .environment(\.layoutDirection, .leftToRight) // content stays LTR
                    .tag(i)
            }
        }
        .tabViewStyle(.page(indexDisplayMode: .never))
        .environment(\.layoutDirection, .rightToLeft) // pages advance right-to-left, like Hebrew
    }

    private func page(_ word: VerseWord, position: Int) -> some View {
        ScrollView {
            VStack(spacing: 10) {
                Text("\(position + 1) / \(words.count)")
                    .font(.caption2)
                    .foregroundStyle(Theme.neutral500)
                Text(pointed(word.h)).font(.system(size: 84)).minimumScaleFactor(0.5).lineLimit(1)
                Text(pronounce(word.h)).font(.subheadline).foregroundStyle(Theme.neutral500)
                Text(tr(word.g)).font(.title2.weight(.medium)).multilineTextAlignment(.center)
                if let n = word.n {
                    Text(tr(n))
                        .font(.subheadline)
                        .foregroundStyle(Theme.neutral400)
                        .multilineTextAlignment(.leading)
                        .padding(.horizontal)
                }
                Button {
                    Speech.say(word.h)
                } label: {
                    Label(ui("Hear it", "再听"), systemImage: "speaker.wave.2")
                }
                .buttonStyle(OutlineButtonStyle())
                .padding(.horizontal, 60)
                .padding(.vertical, 8)
            }
            .frame(maxWidth: .infinity)
            .padding(.horizontal)
        }
        .padding(.top, 12)
    }
}

/// Wrapping layout that flows right-to-left, like Hebrew text.
struct VerseFlow: Layout {
    let spacing: CGFloat = 12

    func sizeThatFits(proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) -> CGSize {
        let width = proposal.width ?? 350
        return CGSize(width: width, height: arrange(subviews, in: width).height)
    }

    func placeSubviews(in bounds: CGRect, proposal: ProposedViewSize, subviews: Subviews, cache: inout ()) {
        let arrangement = arrange(subviews, in: bounds.width)
        for (i, p) in arrangement.points.enumerated() {
            subviews[i].place(at: CGPoint(x: bounds.maxX - p.x, y: bounds.minY + p.y),
                              anchor: .topTrailing, proposal: ProposedViewSize(width: bounds.width, height: nil))
        }
    }

    // x is each word's trailing-edge offset from the right margin
    private func arrange(_ subviews: Subviews, in width: CGFloat) -> (points: [CGPoint], height: CGFloat) {
        var points: [CGPoint] = []
        var x: CGFloat = 0, y: CGFloat = 0, rowHeight: CGFloat = 0
        for sv in subviews {
            // propose the row width, so a caption that wraps is measured as tall as it is drawn
            let size = sv.sizeThatFits(ProposedViewSize(width: width, height: nil))
            if x > 0, x + size.width > width {
                x = 0
                y += rowHeight + spacing
                rowHeight = 0
            }
            points.append(CGPoint(x: x, y: y))
            x += size.width + spacing
            rowHeight = max(rowHeight, size.height)
        }
        return (points, y + rowHeight)
    }
}
