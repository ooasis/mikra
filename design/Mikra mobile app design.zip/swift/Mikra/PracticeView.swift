import SwiftUI

/// Practice now: one short run that mixes words (your sets first, then the core band) with a verse.
/// Each item is a flip card: tap to see the back, then Again (it comes back later) or Got it.
struct PracticeView: View {
    @EnvironmentObject var store: Store

    private enum Item: Identifiable {
        case word(WordCard), verse(Verse)
        var id: String {
            switch self {
            case .word(let w): return "w" + w.id
            case .verse(let v): return "v" + v.id
            }
        }
    }

    @State private var items: [Item] = []
    @State private var index = 0
    @State private var revealed = false
    @State private var reading: Verse?

    private var current: Item? { index < items.count ? items[index] : nil }

    var body: some View {
        VStack(spacing: 0) {
            HStack(alignment: .firstTextBaseline) {
                Text(ui("Practice", "练习")).font(.title2.weight(.medium))
                Spacer()
                if !items.isEmpty {
                    Text("\(min(index + 1, items.count)) / \(items.count)").font(.caption).foregroundStyle(Theme.neutral500)
                }
            }
            .padding(.horizontal)
            .padding(.top, 8)

            ProgressLine(fraction: items.isEmpty ? 0 : Double(index) / Double(items.count))
                .padding(.horizontal)
                .padding(.top, 10)

            if let item = current {
                card(item)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .cardSurface(lit: revealed)
                    .contentShape(.rect)
                    .onTapGesture { flip() }
                    .padding(16)
                actions
            } else if !items.isEmpty {
                finished
            }
        }
        .background(Theme.ground)
        .onAppear { if items.isEmpty { items = Self.build(store) } }
        .onDisappear { Speech.stop() }
        .fullScreenCover(item: $reading) { v in VerseView(verse: v, mode: .passive) }
    }

    private static func build(_ store: Store) -> [Item] {
        let mine = store.sets.flatMap(\.ids).compactMap { wordCardByID[$0] }.shuffled()
        let core = Array(wordDeck.prefix(100)).shuffled()
        var seen = Set<String>()
        let words = (mine + core).filter { seen.insert($0.id).inserted }.prefix(9)
        var out = words.map(Item.word)
        if let verse = store.waveVerse ?? store.todaysVerse ?? store.ritualVerses.first {
            out.insert(.verse(verse), at: min(4, out.count))
        }
        return out
    }

    @ViewBuilder
    private func card(_ item: Item) -> some View {
        switch item {
        case .word(let w):
            VStack(spacing: 10) {
                Text(pointed(w.h)).font(.system(size: 96)).minimumScaleFactor(0.5).lineLimit(1)
                if revealed {
                    Text(tr(w.g)).font(.title2.weight(.medium)).multilineTextAlignment(.center)
                    Text(pronounce(w.h)).font(.callout).foregroundStyle(Theme.neutral500)
                    if let p = w.p { Text(tr(p)).font(.caption).foregroundStyle(Theme.neutral500) }
                } else {
                    tapHint
                }
            }
            .padding(24)
        case .verse(let v):
            VStack(alignment: .leading, spacing: 14) {
                Text(ui("VERSE", "经文") + " · " + tr(v.book) + " \(v.c):\(v.v)")
                    .font(.caption2).tracking(1).foregroundStyle(Theme.accent)
                VerseFlow {
                    ForEach(Array(v.words.enumerated()), id: \.offset) { _, word in
                        Text(pointed(word.h)).font(.system(size: 32))
                    }
                }
                if revealed {
                    Text(v.text).font(.body).foregroundStyle(Theme.neutral400)
                    Button { reading = v } label: {
                        Label(ui("Read this verse", "打开经文"), systemImage: "arrow.right")
                    }
                    .buttonStyle(OutlineButtonStyle())
                } else {
                    tapHint.frame(maxWidth: .infinity)
                }
            }
            .padding(20)
        }
    }

    private var tapHint: some View {
        Label(ui("Tap to flip", "点按翻面"), systemImage: "hand.tap")
            .font(.footnote).foregroundStyle(Theme.neutral500).padding(.top, 12)
    }

    private var actions: some View {
        HStack(spacing: 8) {
            Button { say() } label: { Image(systemName: "speaker.wave.2.fill") }
                .buttonStyle(IconButtonStyle())
                .accessibilityLabel(ui("Play", "朗读"))
            Button(ui("Again", "再看一次")) { again() }
                .buttonStyle(OutlineButtonStyle(prominent: false))
            Button { gotIt() } label: { Label(ui("Got it", "记住了"), systemImage: "checkmark") }
                .buttonStyle(OutlineButtonStyle())
        }
        .padding(.horizontal)
        .padding(.bottom, 8)
    }

    private var finished: some View {
        VStack(spacing: 14) {
            Spacer()
            Text("כָּל הַכָּבוֹד").font(.system(size: 44))
            Text(ui("That's the run.", "这一轮完成了。")).font(.title3.weight(.medium))
            Button(ui("Another round", "再来一轮")) {
                items = Self.build(store); index = 0; revealed = false
            }
            .buttonStyle(OutlineButtonStyle())
            .padding(.horizontal, 40)
            Spacer()
        }
    }

    private func flip() {
        if !revealed { say() }
        withAnimation(.easeOut(duration: 0.15)) { revealed.toggle() }
    }

    private func say() {
        switch current {
        case .word(let w): Speech.say(words: w.units.map(\.h))
        case .verse(let v): Speech.say(verse: v, pace: store.pace)
        case nil: break
        }
    }

    /// Back of the queue: it comes round again before the run ends.
    private func again() {
        guard let item = current else { return }
        items.append(item)
        advance()
    }

    /// Got it shows the back first if you haven't looked; a second tap moves on.
    private func gotIt() {
        if !revealed { flip() } else { advance() }
    }

    private func advance() {
        Speech.stop()
        revealed = false
        withAnimation(.easeOut(duration: 0.2)) { index += 1 }
    }
}
