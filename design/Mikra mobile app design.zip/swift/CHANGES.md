# Mikra: Nocturne redesign (1a + 2b + 3b)

Drop these files into `Mikra/` and replace the existing ones, then run `xcodegen` (project.yml picks up `Mikra/` as a folder, so the two new files are included automatically).

**I couldn't compile this here (no Xcode), so build it once and expect a few small fixes.**

## New files
- **Theme.swift**: Nocturne colours (dark uses Nocturne, light keeps the system colours), `OutlineButtonStyle`, `IconButtonStyle`, `.cardSurface()`, `FadingRule`, `CrumbLine` + `.crumbs()`, `ProgressLine`, and `ui(en, zh)` for interface copy in the chosen language.
- **PracticeView.swift**: Practice now. A mixed run of about 9 words (your sets first, then the top-100 band) with one verse slotted in (the wave verse, else today's, else the book's first). Flip cards with Again / Got it, an "Open verse" link to the reader, and an end-of-run screen.

## Changed files
- **HomeView.swift** (1a): adds `Route.practice` and an outlined Practice now bar above the sections. Tiles sit on the Nocturne surface; your own sets now sit with the built-in Words decks and carry an accent outline instead of the orange tint. The search field is restyled and rows are separated by fading rules. Every pushed screen gets a breadcrumb (`מִקְרָא › Section › Screen`, where tapping מִקְרָא pops to root), set in one place in `navigationDestination`.
- **VerseView.swift** (2b): a chapter rail of verse ticks across the top, running right to left (tall = current, tinted = read). The verse sits on a surface card. Controls are hidden by default: tap a word to hear it and open its sheet, long-press to play the verse, swipe up (or tap the hint line) for a sheet with help, pace, recording and Done. A permanent hint line at the bottom. Wave mode keeps its Check / Struggled / Owned it footer in view. The yellow spoken-word highlight becomes accent-800, and the note dot uses the accent.
- **WordDeckView.swift** (3b): each page is a flip card with a lit edge when turned over, plus a progress line. The action bar is now speaker, sets/listen, **Again**, **Got it**. Again re-queues the card at the end of the run; Got it reveals the card first, then advances, and the last one closes the deck. Pages are now keyed by position, because Again can queue a card twice.
- **App.swift**: `.tint(Theme.accent)`.

## Untouched
- `vowelColor()` / `pointed()`: the per-vowel colours stay as they were.
- `Store`, the SRS and the data, plus the DEBUG hooks; `-openPractice` is new.
- Library, Lesson, Scan and Settings screens get the breadcrumb and tint only. They would need their own restyling pass to match the mocks fully.

## Notes
- Icons are SF Symbols. Nocturne specifies Phosphor, which would need the Phosphor asset catalog added.
- Interface strings I touched go through `ui()` and follow the gloss-language setting. Untouched screens are still English.
- On screens that set `.navigationTitle`, the breadcrumb replaces the inline title through `ToolbarItem(.principal)`.
